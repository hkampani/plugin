<?php

/**
* Calls the QRCodeMetaBox Metabox class on the page edit screen
*/
if(!function_exists('google_call_Metabox_qrcodemetabox')){
	function google_call_Metabox_qrcodemetabox(){
		return new google_Metabox_qrcodemetabox();
	}
	if(is_admin()){
		add_action('load-post.php', 'google_call_Metabox_qrcodemetabox');
		add_action('load-post-new.php', 'google_call_Metabox_qrcodemetabox');
	}
}

/** 
*  Add QRCodeMetaBox to the admin interface
*/
if(!class_exists('google_Metabox_qrcodemetabox')){
	class google_Metabox_qrcodemetabox{
		
		public function __construct(){
			add_action('add_meta_boxes', array(&$this, 'add_page_meta_box'));
		}
		/**
		 * Adds the meta box container
		 */
		public function add_page_meta_box(){
			add_meta_box( 
				 'google-page-meta-box-qrcodemetabox'
				,esc_html__('tik QR Code Generator', 'qr-code')
				,array(&$this, 'render_meta_box_content')
				,array('page', 'post')
				,'normal'
				,'high'
				,null
			);
		}
		/**
		 * Render Meta Box content
		 */
		public function render_meta_box_content($object){
			//	get form fields and default values
			$html_form_field = google_Forms_QRCode::display_form_fields_options();
			$fields_default = google_Forms_QRCode::get_fields_default_value();
			
			//	shortcode preparation
			$sh_curent = '[tik_qrcode';
			foreach($fields_default as $attr => $val){
				if($val!=''){
					$sh_curent .= ' ' . $attr . '="' . $val . '"';
				}
			}
			$sh_curent .= ']';
			
			//	display
			$o = '<table class="form-table">';
			$o .= '<tbody>';
			$o .= '<tr>';
			$o .= '<th>' . esc_html__('Shortcode Generated:', 'qr-code') . '</th>';
			$o .= '</tr><tr>';
			$o .= '<td>';
			$o .= '<input type="hidden" id="google_shortcode_generator_sc_name" value="tik_qrcode" />';
			$o .= '<input type="hidden" id="google_shortcode_generator_fields_default" value="' . esc_attr(json_encode($fields_default)) . '" />';
			$o .= '<code id="google_shortcode_generator_display">' . esc_html($sh_curent) . '</code>';
			$o .= '</td>';
			$o .= '</tr><tr>';
			$o .= '<th>' . esc_html__('QR Code settings:', 'qr-code') . '</th>';
			$o .= '</tr><tr>';
			$o .= '<td>';
			$o .= $html_form_field;
			$o .= '</td>';
			$o .= '</tr>';
			$o .= '</tbody></table>';
			
			echo $o;
		}
	}
}