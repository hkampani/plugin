<?php
/** 
 */
if(!class_exists('google_Shortcodes_qrcodeshortcode')){
	class google_Shortcodes_qrcodeshortcode{
		/**
		* Displays through shortcode
		* [tik_qrcode] for default display
		* and
		* [tik_qrcode key="value"] for custom display
		*/
		public static function google_shortcode_qrcodeshortcode_handler($atts){
			//	get schortcode custom and default values
			$args = shortcode_atts(google_Forms_QRCode::get_fields_default_value(), $atts);
			//	validate fields
			$fields_valid = google_Forms_QRCode::validate_fields($args);
			//	display QR Code img
			$o = google_qrcode_do_display($fields_valid);
			
			return $o;
		}
	}
	add_shortcode('tik_qrcode', array('google_Shortcodes_qrcodeshortcode', 'google_shortcode_qrcodeshortcode_handler'));
}
?>