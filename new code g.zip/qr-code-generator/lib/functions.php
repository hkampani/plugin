<?php
/**
*	Display QR Code structure
*	@param array $p_qrcode_values : fields array
*	@param boolean $p_title_allreadysend : is title allready displayed (widget)
*/
global $google_qrcode_displayed;

if(!function_exists('google_qrcode_do_display')){
	function google_qrcode_do_display($p_qrcode_values, $p_title_allreadysend = false){
		
		global $google_qrcode_displayed;
		$google_qrcode_displayed = true;
		
		//	get QR Code values
		foreach($p_qrcode_values as $attr => $val){
			${'qrcode_' . $attr} = $val;
		}
		
		//	prepare QR Code values
		$qrcode_unique_id = rand(0, 99) . uniqid() . rand(0, 99);
		$qrcode_img_id = esc_attr('google_qrcode_outputimg_' . $qrcode_unique_id);
		
		$qrcode_title = (!empty($qrcode_title)) ? esc_html($qrcode_title) : '';
		$qrcode_content = (!empty($qrcode_content)) ? esc_attr($qrcode_content) : esc_attr(esc_url((isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"));
		$qrcode_ecclevel = (!empty($qrcode_ecclevel)) ? esc_attr($qrcode_ecclevel) : '';
		$qrcode_new_window = (!empty($qrcode_new_window)) ? esc_attr($qrcode_new_window) : '';
		$qrcode_css_shadow = (!empty($qrcode_css_shadow)) ? esc_attr($qrcode_css_shadow) : '';
		$qrcode_align = (!empty($qrcode_align)) ? esc_attr($qrcode_align) : '';
		$qrcode_size = (!empty($qrcode_size)) ? esc_attr($qrcode_size) : '';
		$qrcode_color = (!empty($qrcode_color)) ? esc_attr($qrcode_color) : '';
		$qrcode_bgcolor = (!empty($qrcode_bgcolor)) ? esc_attr($qrcode_bgcolor) : '';
		$qrcode_alt = (!empty($qrcode_alt)) ? esc_attr($qrcode_alt) : 'QR Code';
		if(!empty($qrcode_url) && strpos($qrcode_url, 'bitcoin:')===0){
			$qrcode_url = (!empty($qrcode_url)) ? esc_attr($qrcode_url) : '';
		}elseif(!empty($qrcode_url)){
			$qrcode_url = (!empty($qrcode_url)) ? esc_attr(esc_url($qrcode_url)) : '';
		}
		
		//	set QR Code style
		$qrcode_cssinline_basic = 'max-width: 100%;';
		$qrcode_cssinline_shadow = (!empty($qrcode_css_shadow)) ? ' box-shadow: 2px 2px 10px #4A4242;' : '';
		if($qrcode_align == 'alignleft'){
			$qrcode_cssinline_align = ' display: inline; float: left; margin-right: 1.5em;';
		}else if($qrcode_align == 'alignright'){
			$qrcode_cssinline_align = ' display: inline; float: right; margin-left: 1.5em;';
		}else if($qrcode_align == 'aligncenter'){
			$qrcode_cssinline_align = ' clear: both; display: block; margin-left: auto; margin-right: auto;';
		}else{
			$qrcode_cssinline_align = '';
		}
		
		//	display QR Code
		$o = '<!-- BEGIN tik QR Code Generator -->';
		$o .= '<input type="hidden" id="' . $qrcode_img_id . '_ecclevel" value="' . $qrcode_ecclevel . '" />';
		$o .= '<input type="hidden" id="' . $qrcode_img_id . '_size" value="' . $qrcode_size . '" />';
		$o .= '<input type="hidden" id="' . $qrcode_img_id . '_color" value="' . $qrcode_color . '" />';
		$o .= '<input type="hidden" id="' . $qrcode_img_id . '_bgcolor" value="' . $qrcode_bgcolor . '" />';
		$o .= '<input type="hidden" id="' . $qrcode_img_id . '_content" value="' . $qrcode_content . '" />';
		
		if(!empty($qrcode_title) && !$p_title_allreadysend) $o .= '<h2>' . $qrcode_title . '</h2>';
		if(!empty($qrcode_url)){
			$o .= '<a href="' . $qrcode_url . '"';
			if(!empty($qrcode_new_window)){
				$o .= ' target="_blank" rel="noopener noreferrer"';
			}
			$o .= '>';
		}
		
		$o .= '<img src="" id="' . $qrcode_img_id . '" alt="' . $qrcode_alt . '" class="google_qrcode"';
		$o .= ' style="' . $qrcode_cssinline_basic . $qrcode_cssinline_shadow . $qrcode_cssinline_align . '" >';
		if(!empty($qrcode_url)) $o .= '</a>';
		$o .= '<!-- END tik QR Code Generator -->';
		
		return $o;
	}
}

/**
* Display Public JS and inline script
*/
if(!function_exists('google_qrcode_inline_script')){
	add_action( 'wp_footer', 'google_qrcode_inline_script' );
	function google_qrcode_inline_script(){
		global $google_qrcode_displayed;
		if($google_qrcode_displayed){
			$o = '<script type="text/javascript" src="' . google_PLUGIN_URL . 'assets/qrcode-v2.js?ver=' . google_VERSION . '"></script>';
			$o .= '<script type="text/javascript" src="' . google_PLUGIN_URL . 'js/google-pkg.js?ver=' . google_VERSION . '"></script>';
			$o .= '<script type="text/javascript">google_qrcode_display();</script>';
			
			echo $o;
		}
	}
}

?>