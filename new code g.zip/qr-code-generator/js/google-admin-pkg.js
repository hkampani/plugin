
/**
*	ShortCode Generator from fields
**/
var google_shortcode_curent = new Object();

function google_qrcode_sc_gen(selected_field, slug){
	
	var field_value = selected_field.value;
	var field_type = selected_field.type;
	var sc_name = document.getElementById('google_shortcode_generator_sc_name').value;
	var fields_default_data = document.getElementById('google_shortcode_generator_fields_default').value;
	var fields_default = JSON.parse(fields_default_data);
	
	//	init with default
	if(Object.keys(google_shortcode_curent).length === 0){
		
		
		
		Object.keys(fields_default).forEach(function (slug){
			google_shortcode_curent[slug] = fields_default[slug];
		});
	}
	
	//	set custom values
	if(field_type=='checkbox' && !selected_field.checked){
		google_shortcode_curent[slug] = '';
	}else{
		google_shortcode_curent[slug] = field_value;
	}
	
	//	display shortocde
	var sc_curent = '[' + sc_name;
	Object.keys(google_shortcode_curent).forEach(function (slug) {
		if(google_shortcode_curent[slug]!=''){
			sc_curent += ' ' + slug + '="' + google_shortcode_curent[slug] + '"';
		}
	});
	sc_curent += ']';
	document.getElementById('google_shortcode_generator_display').innerHTML = sc_curent;
	
	return false;
}