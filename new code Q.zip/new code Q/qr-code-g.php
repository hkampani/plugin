<?php
/*
Plugin Name: qr code g
Description: Generate QR Code through Widget and Shortcode.
Version: 0.5
Author: himanshu kampani
Author URI:  https://himanshuk.sgedu.site/real/cars44/

*/

if(!defined('google_PLUGIN_URL')) define('google_PLUGIN_URL', plugin_dir_url( __FILE__ ));
if(!defined('google_PLUGIN_PATH')) define('google_PLUGIN_PATH', plugin_dir_path( __FILE__ ));
if(!defined('google_FILE')) define('google_FILE', plugin_basename(__FILE__));
if(!defined('google_VERSION')) define('google_VERSION', '0.5');

require_once(google_PLUGIN_PATH . 'lib/functions.php');
//	Class Forms requirement
require_once(google_PLUGIN_PATH . 'lib/class.forms.php');
//	Class FormsQRCode requirement
require_once(google_PLUGIN_PATH . 'lib/class.forms_qrcode.php');
//	Class Shortcodes requirement
require_once(google_PLUGIN_PATH . 'lib/class.shortcodes_qrcodeshortcode.php');
//	Class Widgets requirement
require_once(google_PLUGIN_PATH . 'lib/class.widgets_qrcodewidget.php');
//	Class Metabox requirement
require_once(google_PLUGIN_PATH . 'lib/class.metabox_qrcodemetabox.php');



//	Add Admin JS
if(!function_exists('google_register_admin_scripts')){
	add_action('admin_enqueue_scripts', 'google_register_admin_scripts');
	function google_register_admin_scripts(){
		if(is_admin()){
			wp_enqueue_script('google-admin-pkg', google_PLUGIN_URL . 'js/google-admin-pkg.js', array(), google_VERSION);
		}
	}
}



?>