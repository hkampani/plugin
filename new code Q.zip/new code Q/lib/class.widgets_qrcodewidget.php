<?php

/**
* Register the Widget QRCodeWidget class
*/
if(!function_exists('google_register_widget_qrcodewidget')){
	function google_register_widget_qrcodewidget(){
		register_widget('google_Widget_qrcodewidget');
	}
	add_action('widgets_init', 'google_register_widget_qrcodewidget');
}

/** 
*  Create QRCodeWidget widget extend WP_Widget
*/
if(!class_exists('google_Widget_qrcodewidget')){
	class google_Widget_qrcodewidget extends WP_Widget{
		
		public function __construct(){
			$widget_ops = array( 
				'classname' => 'google_Widget_qrcodewidget',
				'description' => esc_html__('Simple QR Code generator', 'qr-code')
			);
			parent::__construct('google_Widget_qrcodewidget', 'QR Code', $widget_ops);
		}
		/**
		 * Front-end Outputs the content of the widget
		 *
		 * @param array $args
		 * @param array $instance
		 */
		public function widget($args, $instance){
			//	validate custom values
			$fields_valid = google_Forms_QRCode::validate_fields($instance);
			
			//	display widget
			$o = $args['before_widget'];
			$o .= $args['before_title'];
			$o .= esc_html(apply_filters('widget_title', $fields_valid['title']));
			$o .= $args['after_title'];
			$o .= '<p>';
			$o .= google_qrcode_do_display($fields_valid, true);
			$o .= '</p>';
			$o .= '<div style="height: 0;clear: both;margin: 0;padding: 0;"></div>';
			$o .= $args['after_widget'];
			
			echo $o;
		}
		/**
		 * Back-end Outputs the options form on admin
		 *
		 * @param array $instance The widget options
		 */
		public function form($instance){
			//	set callable functions to get ids values
			$google_function_ids = array(
				'_id' => array(&$this, 'get_field_id'), 
				'_name' => array(&$this, 'get_field_name')
			);
			//	get form fields with custom values
			$html_form_field = google_Forms_QRCode::display_form_fields($instance, $google_function_ids);
			
			//	display
			$o = '<p>';
			$o .= $html_form_field;
			$o .= '</p>';
			
			echo $o;
		}
		/**
		 * Processing widget options on save
		 *
		 * @param array $new_instance The new options
		 * @param array $old_instance The previous options
		 */
		public function update($new_instance, $old_instance){
			if(empty($new_instance)) return '';
			//	validate fields values
			$instance = google_Forms_QRCode::validate_fields($new_instance);
			
			return $instance;
		}
	}
}